import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import com.cg.ems.util.JPAUtil;

public class TestInheritanceDemo {

	public static void main(String[] args)
	{
	Emp rahul=new Emp();
	rahul.setEmpName("rahul chauhan");
	rahul.setEmpSal(60000);
	Manager vaishali=new Manager();
	vaishali.setEmpName("VaishaliS");
	vaishali.setEmpSal(5000);	
	vaishali.setDeptName("Java");
	EntityManager em=JPAUtil.getEntityManager();
	
	EntityTransaction trans=em.getTransaction();
	trans.begin();
	em.persist(rahul);
	em.persist(vaishali);
	trans.commit();
	System.out.println("data is inserted");
	}

}
